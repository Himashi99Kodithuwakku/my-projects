package coursework;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.Arrays;

public class FuelQueue {


    static int queue = 6;


    //creating 5  arrays for 5 queues
    static String[][] queue1 = new String[queue][];
    static String[][] queue2 = new String[queue][];
    static String[][] queue3 = new String[queue][];
    static String[][] queue4 = new String[queue][];
    static String[][] queue5 = new String[queue][];


    static int fuelStock = 6600;
    static int stockReachvalue = 500;

    static int served = 0;

    static int liters = 0;


    static  int  income_1 = 0;
    static  int  income_2 = 0;
    static  int  income_3 = 0;
    static  int  income_4 = 0;
    static  int  income_5 = 0;

    static int queue1_liters =0;
    static int queue2_liters =0;
    static int queue3_liters =0;
    static int queue4_liters =0;
    static int queue5_liters =0;



    static Scanner chooseMethod = new Scanner(System.in);

    public static void mainMenu() {

        Scanner chooseMethod = new Scanner(System.in);



        //Main menu

        while (true) {
            System.out.println("====|Fuel Queue Management System|==== ");
            System.out.println(" ");
            System.out.println("Choose from here");
            System.out.println(" ");
            System.out.println("100 or VFQ -> View all Fuel Queues");
            System.out.println("101 or VEQ -> View all Empty Queue ");
            System.out.println("102 or ACQ -> Add customer to a queue ");
            System.out.println("103 or RCQ -> Remove Customer from a Queue ");
            System.out.println("104 or PCQ -> Remove a served customer ");
            System.out.println("105 or VCS -> View Customer Sorted in alphabetical order ");
            System.out.println("106 or SPD -> Store program data into file ");
            System.out.println("107 or LPD -> Load program data from file ");
            System.out.println("108 or STK -> View Remaining Fuel Stock ");
            System.out.println("109 or AFS -> Add Fuel Stock ");
            System.out.println("110 or IFQ -> Income of each Fuel Queue ");
            System.out.println("999 or EXT -> Exit the program");
            System.out.println(" ");
            System.out.print("Enter the menu number or code -> ");
            String choose = chooseMethod.next();
            System.out.println(" ");


            // getting input


            if ((choose.equals("100") || (choose.equalsIgnoreCase("VCQ")))) {
                System.out.println("View all Fuel Queues");
                viewAllQueues();

            } else if ((choose.equals("101") || (choose.equalsIgnoreCase("VEQ")))) {
                System.out.println("View all empty  Queues");
                 displayEmptyQueues();

            } else if ((choose.equals("102") || (choose.equalsIgnoreCase("ACQ")))) {
                System.out.println(" Add customer to a queue");
                AddPassenger();

            } else if ((choose.equals("103") || (choose.equalsIgnoreCase("RCQ")))) {
                System.out.println("Remove Customer from a Queue");
                 removeCustomer();

            } else if ((choose.equals("104") || (choose.equalsIgnoreCase("PCQ")))) {

                 removeServedCustomer(queue1,queue2,queue3,queue4,queue5);

            } else if ((choose.equals("105") || (choose.equalsIgnoreCase("VCS")))) {
                System.out.println("View Customer Sorted in alphabetical order");
                 alphabetOrderName();

            } else if ((choose.equals("106") || (choose.equalsIgnoreCase("SPD")))) {
                System.out.println("Store program data into file");
                   storeData();


            } else if ((choose.equals("107") || (choose.equalsIgnoreCase("LPD")))) {
                System.out.println("Load program data from file");
                 loadData();

            } else if ((choose.equals("108") || (choose.equalsIgnoreCase("STK")))) {
                System.out.println("View Remaining Fuel Stock");
                  remainingStock();

            } else if ((choose.equals("109") || (choose.equalsIgnoreCase("AFS")))) {
                System.out.println("Add Fuel Stock");
                  addFuelStock();

            } else if ((choose.equals("110") || (choose.equalsIgnoreCase("IFQ")))) {
                System.out.println("Income of each Fuel Queue");
                incomeFuelQueue();


            } else if ((choose.equals("999") || (choose.equalsIgnoreCase("EXT")))) {
                {
                    System.out.println("Exit the program");
                    break;


                }
            }

        }
    }



    public static int AddPassenger() {
        // get customer details

        Passenger person = new Passenger();
        System.out.println("Enter Queue number (1-5):");
        int queuenum = chooseMethod.nextInt();
        chooseMethod.nextLine();
        System.out.println("Enter token number (0-5):");
        int tokennum = chooseMethod.nextInt();
        System.out.println("Enter First name:");
        person.setFirstName(chooseMethod.next());
        System.out.println("Enter Last name:");
        person.setLastName(chooseMethod.next());
        System.out.println("Enter Vehicle number:");
        person.setVehicleNumber(chooseMethod.next());
        System.out.println("Enter number of liters required:");
        person.setNoOfLiters(chooseMethod.next());

        System.out.println(person.getFirstName() + " added to queue" + queuenum);

        // store customer data in array
        String[] details = {person.getFirstName(), person.getLastName(), person.getVehicleNumber(), person.getNoOfLiters()};
        liters = Integer.parseInt(details[3]);
        fuelStock = fuelStock - liters;
        served = served + liters;




                for (int i =0 ;i < queue; i ++)
                    if (queuenum == 1) {

                        queue1[tokennum] = details;
                        queue1_liters = Integer.parseInt(details[3]);


                    } else if (queuenum == 2) {
                        queue2[tokennum] = details;
                        queue2_liters = Integer.parseInt(details[3]);


                    } else if (queuenum == 3) {
                        queue3[tokennum] = details;
                        queue3_liters = Integer.parseInt(details[3]);


                    } else if (queuenum == 4) {
                        queue4[tokennum] = details;
                        queue4_liters = Integer.parseInt(details[3]);


                    } else if (queuenum == 5) {
                        queue5[tokennum] = details;
                        queue5_liters = Integer.parseInt(details[3]);


                    }

        return fuelStock;




    }
    public static void viewAllQueues() {
        //viewing all the queues
        System.out.println("Queue 1\n");
        for (int i = 0; i <queue; i++){
          System.out.println( Arrays.toString(queue1[i]));
      }
        System.out.println();
        System.out.println("Queue 2\n");
        for (int i = 0; i <queue; i++){
            System.out.println( Arrays.toString(queue2[i]));
        }
        System.out.println();
        System.out.println("Queue 3\n");
        for (int i = 0; i <queue; i++){
            System.out.println( Arrays.toString(queue3[i]));
        }
        System.out.println();
        System.out.println("Queue 4\n");
        for (int i = 0; i <queue; i++){
            System.out.println( Arrays.toString(queue4[i]));
        }
        System.out.println();
        System.out.println("Queue 5\n");
        for (int i = 0; i <queue; i++){
            System.out.println( Arrays.toString(queue5[i]));
        }



    }

    public static void displayEmptyQueues() {

        // display all the empty places in the queues

        System.out.println("  ");
        System.out.println("Queue 1\n");
        for (int i = 0; i < queue; i++) {
            if (queue1[i]== null) {
                System.out.println("Empty");
            } else
                System.out.println(" token number " + i + " occupied by " + Arrays.toString(queue1[i]));
        }
        System.out.println("  ");
        System.out.println("Queue 2\n");
        for (int i = 0; i < queue; i++) {
            if (queue2[i]== null) {
                System.out.println("Empty");

            } else
                System.out.println(" token number " + i + " occupied by " + Arrays.toString(queue2[i]));
        }
        System.out.println("  ");
        System.out.println("Queue 3\n");
        for (int i = 0; i < queue; i++) {
            if (queue3[i]== null) {
                System.out.println("Empty");
            } else
                System.out.println(" token number " + i + " occupied by " +Arrays.toString(queue3[i])) ;
        }
        System.out.println("  ");
        System.out.println("Queue 4\n");
        for (int i = 0; i < queue; i++) {
            if (queue4[i]==null) {
                System.out.println("Empty");
            } else
                System.out.println(" token number " + i + " occupied by " +Arrays.toString(queue4[i]));
        }
        System.out.println("  ");
        System.out.println("Queue 5\n");
        for (int i = 0; i < queue; i++) {
            if (queue5[i]==null) {
                System.out.println("Empty");
            } else
                System.out.println(" token number " + i + " occupied by " + Arrays.toString(queue5[i]));
        }
    }

    public static void removeCustomer() {

        // remove a customer  from specific location

        int tokenNo;
        System.out.println("Enter queue number :");
        int queunum = chooseMethod.nextInt();

        if (queunum == 1) {
            System.out.println("Enter  token number :");
            tokenNo = chooseMethod.nextInt();
            for (int i = 0; i < queue; i++) {
                if ((i) == tokenNo) {
                    queue1[i] = null;
                    // when customer remove from the queue , liters add into fuel stock
                    fuelStock = fuelStock +   queue1_liters ;
                    System.out.println("customer " + " " + i + " " + "is Removed");
                }
            }

        } else if (queunum == 2) {

            System.out.println("Enter  token number :");
            tokenNo = chooseMethod.nextInt();
            for (int i = 0; i < queue; i++) {
                if ((i) == tokenNo) {
                    queue2[i] = null;
                    fuelStock = fuelStock +   queue2_liters ;
                    System.out.println("customer " + " " + i + " " + "is Removed");
                }
            }
        } else if (queunum ==3) {
            System.out.println("Enter  token number :");
            tokenNo = chooseMethod.nextInt();
            for (int i = 0; i < queue; i++) {
                if ((i) == tokenNo) {
                    queue3[i] = null;
                    fuelStock = fuelStock +   queue3_liters ;
                    System.out.println("customer " + " " + i + " " + "is Removed");
                }else{
                    System.out.println("");
                }

            }

        }else if (queunum ==4) {

            System.out.println("Enter  token number :");
            tokenNo = chooseMethod.nextInt();
            for (int i = 0; i < queue; i++) {
                if ((i) == tokenNo) {
                    queue4[i] = null;
                    fuelStock = fuelStock +   queue4_liters ;
                    System.out.println("customer " + " " + i + " " + "is Removed");
                } else {
                    System.out.println("");
                }
            }


        }else{
            System.out.println("Enter  token number :");
            tokenNo = chooseMethod.nextInt();
            for (int i = 0; i < queue; i++) {
                if ((i) == tokenNo) {
                    queue5[i] = null;
                    fuelStock = fuelStock +   queue5_liters ;
                    System.out.println("customer " + " " + i + " " + "is Removed");
                } else {
                    System.out.println("");
                }
            }
        }
    }

    public static void removeServedCustomer(String [][] queue1,String[][]queue2,String [][] queue3,String [][]queue4,String[][] queue5 ) {

        // remove  served customer

        System.out.println("Enter queue number:");
        int  queuenum = chooseMethod.nextInt();


        if (queuenum == 1) {

            queue1[0] =null;

            for (int i = 0;i <5;i++){
                queue1[i] =queue1[i+1];
            }
            queue1[5] =null;

        }

        if (queuenum == 2) {

            queue2[0] =null;

            for (int i = 0;i <5;i++){
                queue2[i] =queue2[i+1];
            }
            queue2[5] =null;

        }

        if (queuenum == 3) {

            queue3[0] =null;

            for (int i = 0;i <5;i++){
                queue3[i] =queue3[i+1];
            }
            queue3[5] =null;
        }

        if (queuenum == 4) {

            queue4[0] =null;

            for (int i = 0;i <5;i++){
                queue4[i] =queue4[i+1];
            }
            queue4[5] =null;
        }

        if (queuenum == 5) {

            queue5[0] =null;

            for (int i = 0;i <5;i++){
                queue5[i] =queue5[i+1];
            }
            queue5[5] =null;
        }




    }
    public static void alphabetOrderName () {

        // display customers name according to alphabetical order

        System.out.println("Enter queue number:");
        int queuenum = chooseMethod.nextInt();

        if (queuenum == 1) {

            // create string array called names
            String []temp;
            for (int i = 0; i < queue; i++) {
                for (int j = i + 1; j < queue; j++) {

                    // to compare one string with other strings
                    if (Arrays.toString(queue1[i]).compareTo(Arrays.toString(queue1[j])) > 0) {
                        // swapping
                        temp = queue1[i];
                        queue1[i] = queue1[j];
                        queue1[j] = temp;
                    }
                }
            }

            // print output array
            System.out.println(
                    "The names in alphabetical order are: ");
            for (int i = 0; i < queue; i++) {
                System.out.println(Arrays.toString(queue1[i]));
            }

        } else if (queuenum == 2) {
            String[] temp;
            for (int i = 0; i < queue; i++) {
                for (int j = i + 1; j < queue; j++) {

                    // to compare one string with other strings
                    if (Arrays.toString(queue2[i]).compareTo(Arrays.toString(queue2[j])) > 0) {
                        // swapping
                        temp = queue2[i];
                        queue2[i] = queue2[j];
                        queue2[j] = temp;
                    }
                }
            }

            // print output array
            System.out.println(
                    "The names in alphabetical order are: ");
            for (int i = 0; i < queue; i++) {
                System.out.println(Arrays.toString(queue2[i]));
            }

        } else if (queuenum == 3) {
            String [] temp;
            for (int i = 0; i < queue; i++) {
                for (int j = i + 1; j < queue; j++) {

                    // to compare one string with other strings
                    if (Arrays.toString(queue3[i]).compareTo(Arrays.toString(queue3[j])) > 0) {
                        // swapping
                        temp = queue3[i];
                        queue3[i] = queue3[j];
                        queue3[j] = temp;
                    }
                }
            }

            // print output array
            System.out.println("The names in alphabetical order are: ");
            for (int i = 0; i < queue; i++) {
                System.out.println(Arrays.toString(queue3[i]));
            }
        } else if (queuenum == 4) {
            String[] temp;
            for (int i = 0; i < queue; i++) {
                for (int j = i + 1; j < queue; j++) {

                    // to compare one string with other strings
                    if (Arrays.toString(queue4[i]).compareTo(Arrays.toString(queue4[j])) > 0) {
                        // swapping
                        temp = queue4[i];
                        queue4[i] = queue4[j];
                        queue4[j] = temp;
                    }
                }
            }

            // print output array
            System.out.println(
                    "The names in alphabetical order are: ");
            for (int i = 0; i < queue; i++) {
                System.out.println(Arrays.toString(queue4[i]));
            }
        } else if (queuenum == 5) {
            String []temp;
            for (int i = 0; i < queue; i++) {
                for (int j = i + 1; j < queue; j++) {

                    // to compare one string with other strings
                    if (Arrays.toString(queue5[i]).compareTo(Arrays.toString(queue5[j])) > 0) {
                        // swapping
                        temp = queue5[i];
                        queue5[i] = queue5[j];
                        queue5[j] = temp;
                    }
                }
            }

            // print output array
            System.out.println(
                    "The names in alphabetical order are: ");
            for (int i = 0; i < queue; i++) {
                System.out.println(Arrays.toString(queue5[i]));
            }
        }


    }

    public static void storeData () {
        // store  customer data into a text file
        try {
            FileOutputStream storefile = new FileOutputStream("storedata.txt");


            for (int i = 0; i < queue; i++) {
                String filedata;

                if (queue1[i] ==(null)) {

                    filedata = "token " + " " + i + " " + "is empty\n";
                } else
                    filedata = "token " + " " + i + " occupied by " + Arrays.toString(queue1[i]) + "\n";
                storefile.write(filedata.getBytes());
            }


            for (int i = 0; i < queue; i++) {
                String filedata;

                if (queue2[i]==(null)) {
                    filedata = "token " + " " + i + " " + "is empty\n";
                } else
                    filedata = "token " + " " + i + " occupied by " + Arrays.toString(queue2[i]) + "\n";
                storefile.write(filedata.getBytes());
            }


            for (int i = 0; i < queue; i++) {
                String filedata;

                if (queue3[i]==(null)) {
                    filedata = "token " + " " + i + " " + "is empty\n";
                } else
                    filedata = "token " + " " + i + " occupied by " +Arrays.toString (queue3[i]) + "\n";
                storefile.write(filedata.getBytes());
            }


            for (int i = 0; i < queue; i++) {
                String filedata;

                if (queue4[i]==(null)) {
                    filedata = "token " + " " + i + " " + "is empty\n";
                } else
                    filedata = "token " + " " + i + " occupied by " + Arrays.toString(queue4[i]) + "\n";
                storefile.write(filedata.getBytes());
            }



            for (int i = 0; i < queue; i++) {
                String filedata;


                if (queue5[i]==(null)) {
                    filedata = "token " + " " + i + " " + "is empty\n";
                } else
                    filedata = "token " + " " + i + " occupied by " + Arrays.toString(queue5[i]) + "\n";
                storefile.write(filedata.getBytes());
            }

            System.out.println("Successfully wrote to the file.");
            storefile.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
        }
    }

    public static void loadData () {
        // load data from  stored file
        try {
            File inputFile = new File("storedata.txt");
            Scanner readfile = new Scanner(inputFile);
            String filedata;
            while (readfile.hasNextLine()) {
                filedata = readfile.nextLine();
                System.out.println(filedata);
            }
            readfile.close();
        } catch (IOException e) {
            System.out.println("Error");
        }


    }
    public static void remainingStock () {
        //display remaining  fuel stock

        System.out.println("Remaining Fuel stock " + fuelStock +" l");


        if (fuelStock <= stockReachvalue) {

            System.out.print("Warning!");

        }

    }

    public static void   addFuelStock(){
        // display served fuel stock

        System.out.println("Served fuel stock :" + served+" l");

    }

    public static void incomeFuelQueue(){
        int q1, q2, q3,q4,q5;


        System.out.println("Enter  Queue number (1-5) \n ");
        int queuenum = chooseMethod.nextInt();
        if (queuenum == 1){

            income_1 = income_1 +queue1_liters;
            q1 =income_1 * 430;
            System.out.println("Queue 1 - income : Rs "+ q1 +"\n");

        }else if (queuenum == 2){

            income_2 = income_2 +queue2_liters;
            q2 =income_2 * 430;
            System.out.println("Queue 2 - income : Rs "+ q2 +"\n");

        }else if(queuenum == 3){
            income_3 = income_3 +queue3_liters;
            q3 =queue3_liters * 430;
            System.out.println("Queue 3 - income : Rs "+ q3 +"\n");

        }else if(queuenum == 4){
            income_4 = income_4 +queue4_liters;
            q4 =queue4_liters * 430;
            System.out.println("Queue 4 - income : Rs "+ q4 +"\n");

        }else if(queuenum == 5){
            income_5 = income_5 +queue5_liters;
            q5 =queue5_liters * 430;
            System.out.println("Queue 5 - income : Rs "+ q5 +"\n");
        }


        }



    public static void main (String[]args){
        //main menu

        mainMenu();
    }
}




package coursework;

public class Passenger {
    private String firstName;
    private String lastName;
    private String vehicleNo;
    private static  String noOfLiters;






    public Passenger() {

    }


    //getter for the first name
    public  String getFirstName() {
        return firstName;
    }
    //setter for the first name
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }


    //getter for the last name
    public  String getLastName() {
        return lastName;
    }
    //setter for the last name
    public void setLastName(String lastName){
        this.lastName = lastName;
    }

    //getter to get the vehicle number
    public String getVehicleNumber() {
        return vehicleNo;
    }

    //setter to set  the vehicle number
    public void setVehicleNumber(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    //getter to get the number of liters
    public static String getNoOfLiters() {
        return noOfLiters;
    }

    //setter to set  the number of liters
    public void setNoOfLiters(String  noOfLiters) {
        this.noOfLiters = noOfLiters;
    }




}
